export async function stopRecording() {
  await window.electronAPI.showDialog({
    type: 'info',
    title: 'Recording Ended',
    message: 'The meeting recording has ended.',
    buttons: ['OK'],
  });
  try {
    const result = await window.electronAPI.stopRecording();
    console.log('Recording stopped successfully:', result);
    // Handle the result as needed
  } catch (error) {
    console.error('Error stopping recording:', error);
  }
}
