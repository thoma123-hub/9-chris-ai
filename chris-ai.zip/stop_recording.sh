#!/bin/bash

echo "[+] Searching for and unloading modules related to 'CombinedChrisAIRecording'..."

pactl list short modules | while read -r id name args; do
  if echo "$args" | grep -q "sink_name=Combined-Chris-AI-Recording" || echo "$args" | grep -q "sink=Combined"; then
    echo "[x] Unloading module ID $id → $name"
    pactl unload-module "$id"
  fi
done

echo "[✓] Unload complete."
