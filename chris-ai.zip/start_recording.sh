#!/bin/bash

OUTPUT_FILE="$1"
if [ -z "$OUTPUT_FILE" ]; then
  echo "Usage: $0 <output_file_path.wav>"
  exit 1
fi

exec 

NULL_SINK_NAME="CombinedChrisAIRecording"
EXISTING=$(pactl list short modules | grep "sink_name=$NULL_SINK_NAME")

if [ -z "$EXISTING" ]; then
  echo "[+] Loading PulseAudio modules..."

  NULL_SINK_ID=$(pactl load-module module-null-sink sink_name=$NULL_SINK_NAME)

  MIC_SOURCE=$(pactl info | grep "Default Source" | cut -d: -f2 | xargs)

  SYSTEM_MONITOR=$(pactl info | grep "Default Sink" | cut -d: -f2 | xargs).monitor

  MIC_LOOP_ID=$(pactl load-module module-loopback source="$MIC_SOURCE" sink=$NULL_SINK_NAME latency_msec=1)

  SYSTEM_LOOP_ID=$(pactl load-module module-loopback source="$SYSTEM_MONITOR" sink=$NULL_SINK_NAME latency_msec=1)

  echo "[+] Recording from $NULL_SINK_NAME.monitor..."
else
  echo "[!] PulseAudio virtual sink already loaded, skipping module reloading."
fi

exec ffmpeg -f pulse -i "$NULL_SINK_NAME.monitor" -ac 2 "$OUTPUT_FILE"
