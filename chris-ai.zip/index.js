// main.js
import { app, BrowserWindow, ipcMain, dialog } from 'electron';
import * as path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { exec, spawn } from 'child_process';
import * as fs from 'fs';
import axios from 'axios';
import FormData from 'form-data';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
let ffmpegProcess = null;
let lastRecordingPath = null;

function createWindow() {
  const win = new BrowserWindow({
    width: 500,
    height: 400,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });


ipcMain.handle('startRecording', async () => {
  if(ffmpegProcess) {
    console.warn('Recording is already in progress.');
    return;
  }

  const timestamp = new Date().toISOString().replace(/[-:.]/g, '').slice(0,15);
  const recordingFilename = `meeting_recording_${timestamp}.wav`;
  const recordingPath = path.join(__dirname, recordingFilename);
  lastRecordingPath = recordingPath;

  ffmpegProcess = spawn(path.join(__dirname, 'start_recording.sh'), [recordingPath]);
  ffmpegProcess.on('error', (error) => {
    console.error('Failed to start recording:', error);
  });
  if (ffmpegProcess.stdout) {
    ffmpegProcess.stdout.on('data', (data) => {
      console.log(`FFmpeg output: ${data}`);
    });
  }

  if (ffmpegProcess.stderr) {
    ffmpegProcess.stderr.on('data', (data) => {
    });
  }

  ffmpegProcess.on('close', (code, signal) => {
    console.log(`FFmpeg process exited with code ${code}, signal ${signal}`);
    ffmpegProcess = null; // Reset the process variable when done
  });
});

ipcMain.handle('stopRecording', async () => {
  if (!ffmpegProcess) {
    console.warn('No recording in progress to stop.');
    return;
  }

  let killed = ffmpegProcess.kill('SIGINT');
  if (!killed) {
    console.warn('Failed to send SIGINT to ffmpeg process.');
  } else {
    console.log('Sent SIGINT to ffmpeg process.');
  }

  const waitAndEscalate = () => {
    if (!ffmpegProcess) return;
    setTimeout(() => {
      if (!ffmpegProcess) return;
      console.warn('FFmpeg did not exit after SIGINT, sending SIGTERM...');
      let termKilled = ffmpegProcess.kill('SIGTERM');
      if (!termKilled) {
        console.warn('Failed to send SIGTERM to ffmpeg process.');
      }
      setTimeout(() => {
        if (!ffmpegProcess) return;
        console.warn('FFmpeg did not exit after SIGTERM, sending SIGKILL...');
        let killKilled = ffmpegProcess.kill('SIGKILL');
        if (!killKilled) {
          console.error('Failed to SIGKILL ffmpeg process.');
        }
      }, 1000);
    }, 2000);
  };
  waitAndEscalate();

  spawn(path.join(__dirname, 'stop_recording.sh'));
  console.log('Recording stop requested.');
});

ipcMain.handle('getRecordingFile', async () => {
  if (lastRecordingPath && fs.existsSync(lastRecordingPath)) {
    return lastRecordingPath;
  }
  return null;
});

ipcMain.handle('uploadFile', async (event, filePath) => {
  if (!filePath || !fs.existsSync(filePath)) {
    return { success: false, message: 'File not found.' };
  }

  const form = new FormData();
  form.append('file', fs.createReadStream(filePath), path.basename(filePath));

  try {
    const response = await axios.post('https://httpbin.org/post', form, {
      headers: {
        ...form.getHeaders(),
      },
      onUploadProgress: (progressEvent) => {
        const percentCompleted = Math.round(
          (progressEvent.loaded * 100) / progressEvent.total
        );
        win.webContents.send('upload-progress', percentCompleted);
      },
    });

    if (response.status === 200) {
      return { success: true, message: 'Upload successful!' };
    } else {
      return { success: false, message: `Upload failed with status: ${response.status}` };
    }
  } catch (error) {
    console.error('Upload error:', error.message);
    return { success: false, message: `Upload failed: ${error.message}` };
  }
});

ipcMain.handle('show-dialog', async (event, options) => {
  return dialog.showMessageBox(null, options);
});

  win.loadFile('index.html');

  // Uncomment to debug in DevTools if something still isn’t appearing:
  // win.webContents.openDevTools();
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
