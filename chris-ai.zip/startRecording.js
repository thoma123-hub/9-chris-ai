
export async function startRecording() {
    try {
        const result = await window.electronAPI.startRecording();
        console.log('Recording started successfully:', result);
        // Handle the result as needed
    } catch (error) {
        console.error('Error starting recording:', error);
    }
}