import { startRecording } from './startRecording.js';
import { stopRecording } from './stopRecording.js';

document.addEventListener('DOMContentLoaded', () => {
  let isRecording = false;
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const timerEl = document.getElementById('timer');
  let timerInterval;
  let seconds = 0;
  const recordingInfoDiv = document.getElementById('recording-info');
  const statusMessageEl = document.getElementById('status-message');
  const uploadProgress = document.getElementById('upload-progress');

  // Hide recording info by default
  if (recordingInfoDiv) recordingInfoDiv.style.display = 'none';

  if (!startBtn || !stopBtn || !timerEl) {
    console.error('One or more DOM elements not found:', { startBtn, stopBtn, timerEl });
    return;
  }

  function formatTime(totalSeconds) {
    const hours = Math.floor(totalSeconds / 3600)
      .toString()
      .padStart(2, '0');
    const minutes = Math.floor((totalSeconds % 3600) / 60)
      .toString()
      .padStart(2, '0');
    const secs = (totalSeconds % 60).toString().padStart(2, '0');
    return `${hours}:${minutes}:${secs}`;
  }

  function updateUI() {
    if (isRecording) {
      startBtn.style.display = 'none';
      stopBtn.style.display = '';
      document.body.style.background =
        'linear-gradient(135deg, #f857a6 0%, #ff5858 100%)';
    } else {
      startBtn.style.display = '';
      stopBtn.style.display = 'none';
      document.body.style.background =
        'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)';
      timerEl.textContent = '00:00:00';
    }

    if (!isRecording && recordingInfoDiv) {
      // Only show after stop or if file exists
      updateRecordingInfo();
    }
  }

  async function updateRecordingInfo() {
    const filePath = await window.electronAPI.getRecordingFile();
    const filePathSpan = document.getElementById('recording-file-path');
    const uploadBtn = document.getElementById('upload-btn');
    if (filePath) {
      filePathSpan.textContent = filePath;
      uploadBtn.disabled = false;
      if (recordingInfoDiv) recordingInfoDiv.style.display = 'flex';
    } else {
      filePathSpan.textContent = 'No recording found.';
      uploadBtn.disabled = true;
      if (recordingInfoDiv) recordingInfoDiv.style.display = 'none';
    }
  }

  // Show file info on first launch if file exists
  updateRecordingInfo();

  startBtn.onclick = () => {
    if (!isRecording) {
      startRecording();
      seconds = 0;
      timerEl.textContent = formatTime(seconds);
      timerInterval = setInterval(() => {
        seconds++;
        timerEl.textContent = formatTime(seconds);
      }, 1000);
      isRecording = true;
      updateUI();
      if (recordingInfoDiv) recordingInfoDiv.style.display = 'none';
      statusMessageEl.textContent = '';
      uploadProgress.style.width = '0%';
      uploadProgress.style.display = 'none';
    }
  };

  stopBtn.onclick = async () => {
    if (isRecording) {
      await stopRecording();
      isRecording = false;
      clearInterval(timerInterval);
      seconds = 0;
      timerEl.textContent = '00:00:00';
      updateUI();
      // Show file info after stopping
      if (recordingInfoDiv) recordingInfoDiv.style.display = 'flex';
      updateRecordingInfo();
    }
  };

  const uploadBtn = document.getElementById('upload-btn');
  uploadBtn.addEventListener('click', async () => {
    const filePath = await window.electronAPI.getRecordingFile();
    if (!filePath) {
      statusMessageEl.textContent = 'Error: Recording file not found.';
      return;
    }

    uploadBtn.disabled = true;
    uploadBtn.textContent = 'Uploading...';
    statusMessageEl.textContent = 'Starting upload...';
    uploadProgress.style.display = 'block';
    uploadProgress.style.width = '0%';

    const result = await window.electronAPI.uploadFile(filePath);

    if (result.success) {
      statusMessageEl.textContent = result.message;
      uploadBtn.textContent = 'Uploaded';
    } else {
      statusMessageEl.textContent = `Error: ${result.message}`;
      uploadBtn.textContent = 'Upload Failed';
      uploadBtn.disabled = false; // Allow retry
    }
  });

  window.electronAPI.onUploadProgress((percentCompleted) => {
    uploadProgress.style.width = `${percentCompleted}%`;
    statusMessageEl.textContent = `Uploading... ${percentCompleted}%`;
  });


  updateUI();
});
