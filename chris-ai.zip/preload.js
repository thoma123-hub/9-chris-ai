const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  startRecording: () => ipcRenderer.invoke('startRecording'),
  stopRecording: () => ipcRenderer.invoke('stopRecording'),
  getRecordingFile: () => ipcRenderer.invoke('getRecordingFile'),
  uploadFile: (filePath) => ipcRenderer.invoke('uploadFile', filePath),
  onUploadProgress: (callback) => ipcRenderer.on('upload-progress', (_event, value) => callback(value)),
  showDialog: (options) => ipcRenderer.invoke('show-dialog', options),
});
